/*
author:zs_dawn
data:2022.4.6

*/

#include "pid.h"
#define ABS(x)		((x>0)? (x): (-x)) //����ֵ

void abs_limit(float *a, float ABS_MAX) {  //����ֵ�����ֵ
    if(*a > ABS_MAX)
        *a = ABS_MAX;
    if(*a < -ABS_MAX)
        *a = -ABS_MAX;
}


void pid_param_init(            //pid������ʼ��
    pid_t *pid,
    float minout,
    float  maxout,
    float 	kp,
    float 	ki
)
{


    pid->MaxOutput = maxout;                //����������
    pid->Minoutput = minout;
    pid->delta_u=0;
    pid->delta_out=0;
    pid->last_delta_out=0;
    pid->p = kp;
    pid->i = ki;


}


/*        ����ʽpid        boost        */
float pid2_calc(pid_t* pid, float get, float set) { //get  Ϊ����ֵ  setΪĿ��ֵ
    pid->err[NOW] = set - get;	//��ֵ

    pid->delta_u = pid->p * (pid->err[NOW] - pid->err[LAST]) + pid->i * pid->err[NOW];
    pid->delta_out = pid->last_delta_out - pid->delta_u;
    abs_limit(&(pid->delta_out), pid->MaxOutput);
    if( pid->delta_out<=pid->Minoutput)
        pid->delta_out=pid->Minoutput;
    pid->last_delta_out = pid->delta_out;	//update last time
    pid->err[LAST] = pid->err[NOW];

    return  pid->delta_out;
}




