/*
author:zs_dawn
data:2022.4.6

*/

#ifndef _IIC_H
#define _IIC_H
#include	"STC15Fxxxx.H"




sbit SCL=P4^0;//ʱ�� D0��SCLK?
sbit SDIN=P4^1;//D1��MOSI�� ����

#define SCLK_Clr() SCL=0
#define SCLK_Set() SCL=1

#define SDIN_Clr() SDIN=0
#define SDIN_Set() SDIN=1


void IIC_Start();
void IIC_Stop();
void Write_IIC_Command(unsigned char IIC_Command);
void Write_IIC_Data(unsigned char IIC_Data);
void Write_IIC_Byte(unsigned char IIC_Byte);
void IIC_Wait_Ack();



#endif
