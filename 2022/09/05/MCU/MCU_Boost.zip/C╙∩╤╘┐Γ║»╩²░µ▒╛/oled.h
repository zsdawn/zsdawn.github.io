#ifndef _OLED_H
#define _OLED_H
#include	"STC15Fxxxx.H"



#define OLED_CMD  0        //д����
#define OLED_DATA 1        //д����
#define OLED_MODE 0

#define OLED_CS_Clr()  OLED_CS=0
#define OLED_CS_Set()  OLED_CS=1

#define OLED_RST_Clr() OLED_RST=0
#define OLED_RST_Set() OLED_RST=1

#define OLED_DC_Clr() OLED_DC=0
#define OLED_DC_Set() OLED_DC=1

/*
author:zs_dawn
data:2022.4.6

*/

//OLEDģʽ����
//0:4�ߴ���ģʽ
//1:����8080ģʽ

#define SIZE 16
#define XLevelL                0x02
#define XLevelH                0x10
#define Max_Column        128
#define Max_Row                64
#define        Brightness        0xFF
#define X_WIDTH         128
#define Y_WIDTH         64





//OLED�����ú���
void OLED_WR_Byte(unsigned dat,unsigned cmd);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Clear(void);

void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size);
void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size);
void OLED_ShowString(u8 x,u8 y, u8 *p,u8 Char_Size);
void OLED_Set_Pos(unsigned char x, unsigned char y);
void OLED_ShowCHinese(u8 x,u8 y,u8 no);
void OLED_ColorTurn(u8 i);
void OLED_DisplayTurn(u8 i);
void oled_sin(float a);
void oled_showpictues(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[]);
void OLED_Init(void);
void OLED_verticalroll_Display(void);
void OLED_obliqueroll_Display(void);

#endif
